
Axaki - Guia Comercial (versão atualizada)
Conteúdo do pacote:
- index.html
- styles.css
- script.js
- logo.png or logo.svg
- README.txt

Alterações nesta versão:
- Logo instalado no canto superior esquerdo.
- Botão "📍 DIVULGUE SEU NEGÓCIO" ao lado do botão Buscar; abre modal com formulário.
- Categoria "Automotivo" adicionada.
- Layout mais limpo e moderno, ícones menores e neutros.
- Formulário em modal envia para axaki.ba@gmail.com via FormSubmit.
- Upload de imagem incluído (opcional). Note que FormSubmit permite anexos; verifique limites no serviço.

Instruções rápidas:
1) Descompacte axaki_site_v2.zip.
2) Faça upload dos arquivos para Vercel (upload direto) ou para Hostinger/public_html.
3) Teste o modal: clique em "DIVULGUE SEU NEGÓCIO", preencha e envie. Você receberá o e-mail em axaki.ba@gmail.com.
4) Para alterar o título da aba, edite a tag <title> em index.html.
5) Para trocar o logo, substitua logo.png (ou logo.svg).

Observação técnica:
- Este é um site estático pronto para hospedagem. Para persistência em banco de dados, será necessário backend.
