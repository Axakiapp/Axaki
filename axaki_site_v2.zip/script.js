
// Sample dataset of businesses
const sampleData = [
  {id:1, nome:"Padaria do Zé", categoria:"Alimentação", telefone:"(73) 99911-2233", endereco:"Av. Brasília, 123 - Centro", cidade:"Eunápolis", descricao:"Pães fresquinhos e lanches."},
  {id:2, nome:"Auto Mecânica Silva", categoria:"Automotivo", telefone:"(73) 98822-3344", endereco:"Rua do Comércio, 45 - Jardim", cidade:"Eunápolis", descricao:"Conserto em geral e revisão."},
  {id:3, nome:"Beleza & Cia", categoria:"Beleza", telefone:"(73) 99733-4455", endereco:"Praça Rui Barbosa, 10 - Centro", cidade:"Eunápolis", descricao:"Cortes, manicure e estética."},
  {id:4, nome:"Clínica São Lucas", categoria:"Saúde", telefone:"(73) 98844-5566", endereco:"Rua das Flores, 200 - Nova", cidade:"Eunápolis", descricao:"Clínica com atendimento médico e exames."},
  {id:5, nome:"Mercantil da Praça", categoria:"Comércio", telefone:"(73) 99655-6677", endereco:"Praça Central, 1 - Centro", cidade:"Eunápolis", descricao:"Mercearia e conveniência 24h."}
];

const cardsEl = document.getElementById('cards');
const searchInput = document.getElementById('searchInput');
const categorySelect = document.getElementById('categorySelect');
const citySelect = document.getElementById('citySelect');
const searchBtn = document.getElementById('searchBtn');
const promoteBtn = document.getElementById('promoteBtn');
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');
const adForm = document.getElementById('adForm');
const catButtons = document.querySelectorAll('.cat');

function renderCards(data){
  cardsEl.innerHTML = '';
  if(!data || data.length===0){
    cardsEl.innerHTML = '<p>Nenhum resultado encontrado.</p>';
    return;
  }
  data.forEach(d=>{
    const div = document.createElement('div');
    div.className='card';
    div.innerHTML = `<h4>${d.nome}</h4>
      <p>${d.descricao}</p>
      <div class="meta"><span>${d.categoria} • ${d.cidade}</span><span>${d.telefone}</span></div>
      <div style="margin-top:8px;font-size:13px;color:#6c757d">${d.endereco}</div>`;
    cardsEl.appendChild(div);
  });
}

// initial render
renderCards(sampleData);

// search handler
function doSearch(){
  const q = searchInput.value.trim().toLowerCase();
  const cat = categorySelect.value;
  const city = citySelect.value;
  let results = sampleData.filter(item=>{
    const matchQ = q === '' || (item.nome + ' ' + item.descricao + ' ' + item.endereco).toLowerCase().includes(q);
    const matchCat = cat === '' || item.categoria === cat;
    const matchCity = city === '' || item.cidade === city;
    return matchQ && matchCat && matchCity;
  });
  renderCards(results);
}

searchBtn.addEventListener('click', doSearch);
searchInput.addEventListener('keydown', function(e){ if(e.key==='Enter'){ doSearch(); }});

// category quick filter
catButtons.forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const c = btn.getAttribute('data-cat');
    categorySelect.value = c;
    doSearch();
  });
});

// Modal handlers
promoteBtn.addEventListener('click', ()=>{
  modal.setAttribute('aria-hidden','false');
});
modalClose.addEventListener('click', ()=> modal.setAttribute('aria-hidden','true'));
modal.addEventListener('click', (e)=>{ if(e.target === modal) modal.setAttribute('aria-hidden','true'); });

// Save form locally for testing (localStorage)
document.getElementById('saveLocal').addEventListener('click', function(){
  const data = {};
  new FormData(adForm).forEach((v,k)=> data[k]=v);
  let list = JSON.parse(localStorage.getItem('axaki_local')||'[]');
  data.id = Date.now();
  list.push(data);
  localStorage.setItem('axaki_local', JSON.stringify(list));
  alert('Cadastro salvo localmente. (Apenas para testes)');
});

// Accessibility: close modal with Escape
document.addEventListener('keydown', function(e){ if(e.key === 'Escape') modal.setAttribute('aria-hidden','true'); });
